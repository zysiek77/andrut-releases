# Products and orders – Fiori Elements V2 template

List report of products → product page (orders table) → order page. SAPUI5 1.148 from the CDN, OData V2 answered in the browser by MockServer (service `ZDEMO_PRODUCTS_SRV`). Same files as the template of the skill `ui5-fiori-elements` – read it before changing anything.

- Entities: `Products` (key `ProductID`) → `to_Orders` (`Orders`); dictionaries `Categories`, `Suppliers`, `Customers`, `Currencies`, `Units` (type `<Name>Value`, one mock file each).
- Dropdowns (`Common.ValueListWithFixedValues`): category, currency, unit. Value help dialog: supplier, customer. Names next to codes: `Common.Text` over `to_<Field>`.
- Rows are saved with `andrut.setData("fe_<EntitySet>")`; after editing `mockdata/*.json` run `resetMockData()` (run_js) and reload.
- `extras/` (in the skill): CSV import and a custom button – copy only when asked.
- Do not switch SAPUI5 to the unversioned URL: in 1.154.0 the `…` overflow menu does not open on phones.
