// controls.js – touch joysticks. Knows NOTHING about three.js or the game.
//
// The game reads only this:
//   controls.move.y   -1 … 1   left stick, up = forward
//   controls.move.x   -1 … 1   left stick, right = +
//   controls.look.x   -1 … 1   right stick, right = +
//   controls.look.y   -1 … 1   right stick, up = +
//   onFire()  – tap on the left half        onJump() – tap on the right half
//
// Rules (do not break them):
// 1. RELATIVE stick: the place where the finger lands is the centre (value 0).
//    Only the distance from that place counts, so a finger that misses the
//    drawn joystick never causes a sudden jump.
// 2. Releasing the finger sets the value to 0 at once; the knob picture glides back.
// 3. TAP = finger lifted within TAP_MS and moved less than DEAD px. Inside DEAD
//    the stick value is 0, so a tap never moves the player.
// 4. A second finger in a half that already has a finger on it is a tap at once
//    (fire while walking, jump while turning).

const RADIUS = 60;   // px of finger travel for full deflection
const DEAD = 10;     // px dead zone (also the tap tolerance)
const TAP_MS = 280;  // longest touch that still counts as a tap
const KNOB_TRAVEL = 34; // px the drawn knob moves at full deflection

class Stick {
  constructor(zone, label, onTap) {
    this.x = 0; this.y = 0;          // output, -1 … 1 (y: up = +)
    this.pointer = null;             // id of the finger that owns the stick
    this.onTap = onTap;
    this.taps = 0;                   // counter, handy for tests
    this.base = document.createElement('div');
    this.base.className = 'stick-base';
    this.base.innerHTML = '<div class="stick-label"></div><div class="stick-knob"></div>';
    this.base.firstChild.textContent = label;
    this.knob = this.base.lastChild;
    zone.appendChild(this.base);
    this.zone = zone;

    zone.addEventListener('pointerdown', e => this.down(e));
    zone.addEventListener('pointermove', e => this.moveTo(e));
    zone.addEventListener('pointerup', e => this.up(e, true));
    zone.addEventListener('pointercancel', e => this.up(e, false));
    zone.addEventListener('lostpointercapture', e => this.up(e, false));
    zone.addEventListener('contextmenu', e => e.preventDefault());
  }

  down(e) {
    e.preventDefault();
    if (this.pointer !== null) { this.tap(); return; }   // rule 4
    this.pointer = e.pointerId;
    this.ox = e.clientX; this.oy = e.clientY;            // rule 1: this point is the centre
    this.t0 = performance.now();
    this.moved = false;
    try { this.zone.setPointerCapture(e.pointerId); } catch (_) {}
    this.base.classList.add('active');
  }

  moveTo(e) {
    if (e.pointerId !== this.pointer) return;
    let dx = e.clientX - this.ox, dy = e.clientY - this.oy;
    let dist = Math.hypot(dx, dy);
    if (dist > DEAD) this.moved = true;
    if (dist > RADIUS) {            // finger went past the edge: drag the centre along,
      const k = RADIUS / dist;      // so reversing the direction answers immediately
      this.ox = e.clientX - dx * k; this.oy = e.clientY - dy * k;
      dx *= k; dy *= k; dist = RADIUS;
    }
    const f = dist <= DEAD ? 0 : (dist - DEAD) / (RADIUS - DEAD) / dist;   // smooth start after the dead zone
    this.x = dx * f; this.y = -dy * f;
    this.draw();
  }

  up(e, mayTap) {
    if (e.pointerId !== this.pointer) return;
    const quick = performance.now() - this.t0 <= TAP_MS;
    this.pointer = null;
    this.x = 0; this.y = 0;                               // rule 2
    this.base.classList.remove('active');
    this.draw();
    if (mayTap && quick && !this.moved) this.tap();       // rule 3
  }

  tap() {
    this.taps++;
    this.base.classList.add('tap');
    setTimeout(() => this.base.classList.remove('tap'), 120);
    this.onTap();
  }

  reset() { if (this.pointer !== null) this.up({ pointerId: this.pointer }, false); }

  draw() {
    this.knob.style.transform = `translate(${this.x * KNOB_TRAVEL}px, ${-this.y * KNOB_TRAVEL}px)`;
  }
}

export function createControls({ left, right, onFire, onJump }) {
  const move = new Stick(left, 'MOVE · tap = fire', onFire);
  const look = new Stick(right, 'LOOK · tap = jump', onJump);

  // Keyboard, only as an extra (tablet with a keyboard, desktop tests):
  // W/S or ↑/↓ walk, A/D strafe, ←/→ turn, R/V look up/down, Space jump, F or Enter fire.
  const keys = new Set();
  const axis = (plus, minus) => (plus.some(k => keys.has(k)) ? 1 : 0) - (minus.some(k => keys.has(k)) ? 1 : 0);
  addEventListener('keydown', e => {
    if (e.repeat) return;
    keys.add(e.code);
    if (e.code === 'Space') onJump();
    if (e.code === 'KeyF' || e.code === 'Enter') onFire();
  });
  addEventListener('keyup', e => keys.delete(e.code));

  // Leaving the app must never leave a stick "stuck".
  const release = () => { move.reset(); look.reset(); keys.clear(); };
  addEventListener('blur', release);
  document.addEventListener('visibilitychange', () => { if (document.hidden) release(); });

  const clamp = v => Math.max(-1, Math.min(1, v));
  return {
    get move() { return { x: clamp(move.x + axis(['KeyD'], ['KeyA'])), y: clamp(move.y + axis(['KeyW', 'ArrowUp'], ['KeyS', 'ArrowDown'])) }; },
    get look() { return { x: clamp(look.x + axis(['ArrowRight'], ['ArrowLeft'])), y: clamp(look.y + axis(['KeyR'], ['KeyV'])) }; },
    sticks: { move, look },
  };
}
