# FPS template (three.js)

A first-person 3D game template for a phone. Two touch joysticks, no start screen.

## Controls (agreed with the user – do not change without asking)
- Left half of the screen = MOVE stick: up/down = walk forward/back, left/right = walk sideways (strafe). Tap = fire.
- Right half of the screen = LOOK stick: left/right = turn, up/down = look up/down. Tap = jump.
- Sticks are RELATIVE: the point where the finger lands is the centre. Missing the drawn
  joystick must never cause a jump of the value. Releasing returns the stick to the centre.
- A second finger on a half that is already held = tap at once (fire while walking, jump while turning).

## Files
- `index.html` – canvas, HUD, two zones (`#zone-left`, `#zone-right`), import map (three 0.170.0, jsdelivr).
- `style.css` – layers: canvas (z 0) < zones (z 1) < HUD (z 2, `pointer-events:none`). Nothing else may cover the zones.
- `controls.js` – touch + keyboard → numbers. No three.js here. Output: `controls.move.{x,y}`, `controls.look.{x,y}` in -1…1, callbacks `onFire`, `onJump`. Constants `RADIUS`, `DEAD`, `TAP_MS` at the top.
- `game.js` – scene, level (`BOXES` list), targets, player physics, shooting. No touch code here. All tuning in `CONFIG` at the top (`strafe: true` turns on sideways walking on the left stick).
- `main.js` – connects the two, HUD, render loop, `window.game`, `andrutDescribe`.

## Rules when extending
- New input (button, gesture) goes to `controls.js` and reaches the game as a number or a callback.
- New gameplay goes to `game.js` (split into more modules when it grows: `level.js`, `enemies.js`, `weapons.js`).
- Keep `game.state` flat numbers/booleans – interact_world prints it before and after.
- New HUD elements: inside `#hud`; a HUD button needs `pointer-events:auto` and must not sit over the stick areas.

## Testing
- `interact_world` drags: walk `{"drag":"#zone-left","by":[0,-60],"ms":300,"hold":1000}` → `z` decreases;
  turn `{"drag":"#zone-right","by":[60,0],"ms":300,"hold":800}` → `yaw` decreases;
  both `{"parallel":[{…left…},{…right…}]}`.
- Taps: `{"click":"#zone-left"}` → `shots` +1; `{"click":"#zone-right"}` → `jumps` +1.
- `run_js`: `JSON.stringify(game.state)`, `game.fire()`, `game.jump()`.
- The world sets `window.andrutLoading` until the first frame is drawn. It needs the internet (three.js from CDN).
