// game.js – the 3D world, the player and shooting. Knows NOTHING about touch:
// it gets plain numbers (-1 … 1) and calls fire() / jump().
import * as THREE from 'three';

export const CONFIG = {
  walkSpeed: 6,          // m/s at full stick
  strafe: true,          // true: left stick sideways = strafe; false: left stick is forward/back only
  turnSpeed: 2.6,        // rad/s at full right stick (left/right)
  pitchSpeed: 1.6,       // rad/s at full right stick (up/down)
  lookCurve: 1.6,        // >1 = finer aiming near the centre of the stick
  maxPitch: 1.4,         // rad (about 80°)
  jumpSpeed: 6.5,
  gravity: 18,
  eyeHeight: 1.6,
  playerRadius: 0.4,
  fireCooldown: 0.15,    // s
  arena: 30,             // half of the arena side, m
};

export function createGame(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8fb8d8);
  scene.fog = new THREE.Fog(0x8fb8d8, 25, 80);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x556644, 1.6));
  const sun = new THREE.DirectionalLight(0xffffff, 2.2);
  sun.position.set(10, 20, 6);
  scene.add(sun);

  const camera = new THREE.PerspectiveCamera(70, 1, 0.05, 200);
  camera.rotation.order = 'YXZ';      // yaw first, then pitch – no roll
  scene.add(camera);

  // ---------- level ----------
  const A = CONFIG.arena;
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(A * 2, A * 2), new THREE.MeshLambertMaterial({ map: gridTexture(A) }));
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  // Solid boxes: [x, z, width, depth, height]. Walls of the arena are boxes too.
  const BOXES = [
    [0, -A, A * 2, 1, 4], [0, A, A * 2, 1, 4], [-A, 0, 1, A * 2, 4], [A, 0, 1, A * 2, 4],
    [-6, -8, 3, 3, 1], [5, -12, 2, 6, 2.5], [-12, 4, 6, 2, 1.5], [10, 6, 4, 4, 0.8],
    [0, -20, 8, 2, 3], [-18, -14, 3, 3, 3], [16, -6, 2, 2, 5], [8, 16, 5, 2, 1.2], [-8, 14, 3, 5, 2],
  ];
  const solids = [];   // { minX, maxX, minZ, maxZ, top } for collisions
  const colors = [0xc98b5e, 0x7d9c6b, 0x9a86b8, 0xb8a05a];
  BOXES.forEach(([x, z, w, d, h], i) => {
    const wall = i < 4;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d),
      new THREE.MeshLambertMaterial({ color: wall ? 0x6f7f8f : colors[i % colors.length] }));
    mesh.position.set(x, h / 2, z);
    scene.add(mesh);
    solids.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, top: h, mesh });
  });

  // Targets: shoot them, they move to a new place.
  const targets = [];
  const targetGeo = new THREE.SphereGeometry(0.5, 20, 14);
  for (let i = 0; i < 6; i++) {
    const t = new THREE.Mesh(targetGeo, new THREE.MeshLambertMaterial({ color: 0xe5483c, emissive: 0x551100 }));
    placeTarget(t);
    scene.add(t);
    targets.push(t);
  }
  function placeTarget(t) {
    t.position.set((Math.random() * 2 - 1) * (A - 4), 1 + Math.random() * 2.5, (Math.random() * 2 - 1) * (A - 4));
    t.userData.phase = Math.random() * 6.28;
  }

  // Gun (child of the camera) and the shot tracer.
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.07, 0.32), new THREE.MeshLambertMaterial({ color: 0x333a44 }));
  gun.position.set(0.2, -0.17, -0.45);
  camera.add(gun);
  const flash = new THREE.PointLight(0xffdd88, 0, 6);
  flash.position.set(0.2, -0.12, -0.8);
  camera.add(flash);
  const tracerGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
  const tracer = new THREE.Line(tracerGeo, new THREE.LineBasicMaterial({ color: 0xfff2a0, transparent: true }));
  tracer.frustumCulled = false;
  tracer.visible = false;
  scene.add(tracer);

  // ---------- player ----------
  // state holds only plain numbers – tests read it through window.game.state
  const state = { x: 0, y: 0, z: 10, yaw: 0, pitch: 0, vy: 0, onGround: true, score: 0, shots: 0, jumps: 0, frames: 0 };
  let cooldown = 0, kick = 0, tracerLife = 0;
  let onHit = () => {};

  // Height of the ground under the player: the floor or the top of a box they stand over.
  function groundAt(x, z, feet) {
    let g = 0;
    for (const s of solids) {
      if (x > s.minX && x < s.maxX && z > s.minZ && z < s.maxZ && s.top <= feet + 0.3) g = Math.max(g, s.top);
    }
    return g;
  }

  // Push the player (a circle) out of boxes that are higher than a small step.
  function collide() {
    const r = CONFIG.playerRadius;
    for (const s of solids) {
      if (s.top <= state.y + 0.3) continue;                // low enough to step / stand on
      const cx = Math.max(s.minX, Math.min(state.x, s.maxX));
      const cz = Math.max(s.minZ, Math.min(state.z, s.maxZ));
      let dx = state.x - cx, dz = state.z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 >= r * r) continue;
      if (d2 > 1e-9) {                                     // outside, touching: push away from the nearest point
        const d = Math.sqrt(d2);
        state.x = cx + dx / d * r; state.z = cz + dz / d * r;
      } else {                                             // centre inside the box: leave through the nearest side
        const out = [[state.x - s.minX, -1, 0], [s.maxX - state.x, 1, 0], [state.z - s.minZ, 0, -1], [s.maxZ - state.z, 0, 1]]
          .sort((a, b) => a[0] - b[0])[0];
        state.x += out[1] * (out[0] + r); state.z += out[2] * (out[0] + r);
      }
    }
  }

  const curve = v => Math.sign(v) * Math.pow(Math.abs(v), CONFIG.lookCurve);

  // One step of the game. move/look: { x, y } in -1 … 1, dt in seconds.
  function update(dt, move, look) {
    state.yaw -= curve(look.x) * CONFIG.turnSpeed * dt;
    state.pitch = Math.max(-CONFIG.maxPitch, Math.min(CONFIG.maxPitch, state.pitch + curve(look.y) * CONFIG.pitchSpeed * dt));

    const fwd = move.y, side = CONFIG.strafe ? move.x : 0;
    const sin = Math.sin(state.yaw), cos = Math.cos(state.yaw);
    state.x += (-sin * fwd + cos * side) * CONFIG.walkSpeed * dt;
    state.z += (-cos * fwd - sin * side) * CONFIG.walkSpeed * dt;
    collide();

    state.vy -= CONFIG.gravity * dt;
    state.y += state.vy * dt;
    const g = groundAt(state.x, state.z, state.y);
    if (state.y <= g) { state.y = g; state.vy = 0; state.onGround = true; }
    else state.onGround = false;

    camera.position.set(state.x, state.y + CONFIG.eyeHeight, state.z);
    camera.rotation.set(state.pitch, state.yaw, 0);

    const t = performance.now() / 1000;
    for (const tg of targets) tg.scale.setScalar(1 + 0.08 * Math.sin(t * 3 + tg.userData.phase));

    cooldown = Math.max(0, cooldown - dt);
    kick = Math.max(0, kick - dt * 6);
    gun.position.z = -0.45 + kick * 0.06;
    flash.intensity = kick > 0.5 ? 8 : 0;
    if (tracerLife > 0) { tracerLife -= dt; tracer.material.opacity = Math.max(0, tracerLife / 0.08); tracer.visible = tracerLife > 0; }

    renderer.render(scene, camera);
    state.frames++;
  }

  const ray = new THREE.Raycaster();
  const centre = new THREE.Vector2(0, 0);
  function fire() {
    if (cooldown > 0) return false;
    cooldown = CONFIG.fireCooldown;
    kick = 1;
    state.shots++;
    camera.updateMatrixWorld();
    ray.setFromCamera(centre, camera);
    const hit = ray.intersectObjects([...targets, ...solids.map(s => s.mesh), floor], false)[0];
    const end = hit ? hit.point : ray.ray.at(100, new THREE.Vector3());
    const start = gun.getWorldPosition(new THREE.Vector3());
    tracerGeo.setFromPoints([start, end]);
    tracerLife = 0.08;
    if (hit && targets.includes(hit.object)) {
      state.score++;
      placeTarget(hit.object);
      onHit(state.score);
    }
    return true;
  }

  function jump() {
    if (!state.onGround) return false;
    state.vy = CONFIG.jumpSpeed;
    state.onGround = false;
    state.jumps++;
    return true;
  }

  function resize(w, h) {
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.fov = w < h ? 80 : 60;       // portrait: wider vertical angle, so the sides are still visible
    camera.updateProjectionMatrix();
  }

  return { scene, camera, renderer, state, targets, solids, update, fire, jump, resize, set onHit(f) { onHit = f; } };
}

// Floor texture with a grid, so movement is visible.
function gridTexture(arena) {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  g.fillStyle = '#7fa66b'; g.fillRect(0, 0, 128, 128);
  g.strokeStyle = '#5f8650'; g.lineWidth = 4; g.strokeRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(arena, arena);            // one square = 2 m
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
