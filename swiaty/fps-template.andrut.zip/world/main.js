// main.js – glue: controls → game → HUD. Keep it small.
import { createControls } from './controls.js';
import { createGame } from './game.js';

const $ = id => document.getElementById(id);
const message = $('message');

try {
  const game = createGame($('view'));
  const controls = createControls({
    left: $('zone-left'),
    right: $('zone-right'),
    onFire: () => game.fire(),
    onJump: () => game.jump(),
  });

  game.onHit = score => {
    $('score-value').textContent = score;
    $('crosshair').classList.add('hit');
    setTimeout(() => $('crosshair').classList.remove('hit'), 120);
  };

  const resize = () => game.resize(innerWidth, innerHeight);
  addEventListener('resize', resize);
  resize();

  // The scene runs from the first moment – there is no start screen.
  let last = performance.now();
  game.renderer.setAnimationLoop(now => {
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now;
    game.update(dt, controls.move, controls.look);
    if (game.state.frames === 1) {
      message.textContent = '';
      window.andrutLoading = false;
      if (window.andrut && andrut.log) andrut.log('3D ready');
    }
  });

  // For tests (run_js, interact_world): state before/after, sticks, direct actions.
  window.game = { scene: game.scene, camera: game.camera, renderer: game.renderer, state: game.state, controls, fire: game.fire, jump: game.jump };
  window.andrutDescribe = () => {
    const s = game.state, m = controls.move, l = controls.look;
    return `FPS: player x=${s.x.toFixed(1)} y=${s.y.toFixed(1)} z=${s.z.toFixed(1)} yaw=${s.yaw.toFixed(2)} pitch=${s.pitch.toFixed(2)}, ` +
      `score ${s.score}, shots ${s.shots}, jumps ${s.jumps}, onGround ${s.onGround}; ` +
      `sticks move(${m.x.toFixed(2)}, ${m.y.toFixed(2)}) look(${l.x.toFixed(2)}, ${l.y.toFixed(2)})`;
  };
} catch (err) {
  message.textContent = '3D failed to start: ' + (err && err.message || err);
  window.andrutLoading = false;
  throw err;
}
