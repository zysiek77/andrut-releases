# Sales Orders – Fiori Elements V2 template

List report of sales orders → order page (items table) → item page (schedule lines table) → schedule line page.
SAPUI5 from the CDN, OData V2 answered in the browser by MockServer. Built on the skill `ui5-fiori-elements` – read it before changing anything.

## Model (`fe/localService/metadata.xml`, service `ZDEMO_SALESORDER_SRV`)
- `SalesOrders` (type `OrderHeader`, key `SalesOrder`) → `to_Items`
- `SalesOrderItems` (type `OrderItem`, keys `SalesOrder` + `SalesOrderItem`) → `to_ScheduleLines`
- `ScheduleLines` (type `OrderScheduleLine`, keys `SalesOrder` + `SalesOrderItem` + `ScheduleLine`)
- A child carries all keys of its parent; the association has a referential constraint on them, so MockServer fills them on Create.
- Entity types are not named like their key property (`OrderHeader`, `CustomerValue`) – keep that.

## Dictionaries (every coded field has one; type `<Name>Value`, one mock file each)
Dropdown (`Common.ValueListWithFixedValues`): `SalesOrderTypes`, `SalesOrganizations`, `DistributionChannels`, `Divisions`, `Currencies`, `PaymentTermsSet`, `IncotermsSet`, `OverallStatuses` (with `Criticality` for the status colour), `ItemCategories`, `Plants`, `Units`, `ScheduleLineCategories`, `DeliveryBlocks`.
Value help dialog: `Customers` (Sold-To Party), `Materials` (choosing a material also fills the unit of the item – `ValueListParameterOut`).
Names next to codes come from `Common.Text` over a navigation property `to_<Field>` (not for currency and unit).
A new coded field needs: dictionary type + set, mock file, association + navigation property, `Common.Text`, `Common.ValueList`.

## Screens (modelled on SAP's Manage Sales Orders)
- All three tables use checkboxes (multi-select): `tableSettings.multiSelect` in `fe/manifest.json` – on the list report and in `sections` of the two object pages.
- List columns and filters: sales order, sold-to party, customer reference, requested delivery date, status, net value, document date.
- Order page header: title = order number, subtitle = name of the order type; header fields sold-to party, status, net value.

## Automatic numbers (`NUMBERING` + `assignNumber()` in `fe/start.js`)
The user never types a key. Order number = highest + 1; item number = highest in the order + 10; schedule line = highest in the item + 1. Key properties are `sap:creatable="false" sap:updatable="false"` in the metadata, so they are read-only on the screens. The only number the user enters is the customer reference (`PurchaseOrderByCustomer`).

## Business rules (`applyRules()` in `fe/start.js`)
Item net value = quantity × net price; item currency = order currency; order net value = sum of its items. Net values are read-only on the screens.

## Data
Rows of every entity set are saved with `andrut.setData("fe_<EntitySet>")`. After editing `mockdata/*.json` run `resetMockData()` (run_js) and reload.

## Known
SAPUI5 is loaded as `https://ui5.sap.com/1.148/resources/…` (long-term version, newest patch). Do not switch to the unversioned URL: in 1.154.0 the `…` overflow menu of toolbars does not open on phones.
Right after a Create, SAPUI5 may log `Cannot read properties of null (reading 'getPath')` from `sap/ui/comp` – harmless, the object is created.
