// Start of the Fiori Elements V2 app in Andrut (no backend, no Fiori Launchpad):
// 1. MockServer answers the OData V2 requests in the browser (metadata.xml + mockdata/<EntitySet>.json),
// 2. a stub replaces the launchpad's ShellUIService (without it Fiori Elements throws on start),
// 3. the component demo.fe (manifest.json) is created and placed on the page.
// Rows of every entity set are kept between visits (andrut.setData under "fe_<EntitySet>").
sap.ui.define([
  "sap/ui/core/util/MockServer", "sap/ui/core/ComponentContainer",
  "sap/ui/core/service/Service", "sap/ui/core/service/ServiceFactory", "sap/ui/core/service/ServiceFactoryRegistry",
  "sap/ui/core/ElementRegistry"
], function (MockServer, ComponentContainer, Service, ServiceFactory, ServiceFactoryRegistry, ElementRegistry) {
  "use strict";
  // Must be the same as sap.app/dataSources/mainService/uri in manifest.json.
  var SERVICE_URI = "/sap/opu/odata/sap/ZDEMO_SALESORDER_SRV/";
  var hasAndrut = typeof window.andrut !== "undefined";
  var base = sap.ui.require.toUrl("demo/fe/localService");
  // sets: entity set name -> { props: property names, types: property -> Edm type, keys: key names, type: "Namespace.EntityType" }
  var server = null, sets = {}, model = null;

  var ShellStub = Service.extend("demo.fe.ShellUIServiceStub", {
    setTitle: function (t) { document.title = t; }, getTitle: function () { return document.title; },
    setHierarchy: function () {}, setRelatedApps: function () {}, setBackNavigation: function () {},
    attachEvent: function () {}, detachEvent: function () {}
  });
  ServiceFactoryRegistry.register("sap.ushell.ui5service.ShellUIService", new ServiceFactory(ShellStub));

  // The start is over when the first page is drawn: Andrut's check_world waits for this signal (set in index.html).
  function ready() {
    var t0 = Date.now(), timer = setInterval(function () {
      if (document.querySelector(".sapMListTbl, .sapUxAPObjectPageLayout") || Date.now() - t0 > 15000) { clearInterval(timer); window.andrutLoading = false; }
    }, 200);
  }
  function fail(e) {
    window.andrutLoading = false;
    document.getElementById("loading").textContent = "Fiori Elements failed to start: " + e.message;
    console.error("Fiori Elements: " + (e.stack || e.message));
  }
  function readSets(xml) {
    var doc = new DOMParser().parseFromString(xml, "application/xml"), types = {};
    var ns = doc.getElementsByTagName("Schema")[0].getAttribute("Namespace");
    Array.prototype.forEach.call(doc.getElementsByTagName("EntityType"), function (t) {
      var info = { props: [], types: {}, keys: [], type: ns + "." + t.getAttribute("Name") };
      Array.prototype.forEach.call(t.getElementsByTagName("Property"), function (p) {
        info.props.push(p.getAttribute("Name")); info.types[p.getAttribute("Name")] = p.getAttribute("Type");
      });
      Array.prototype.forEach.call(t.getElementsByTagName("PropertyRef"), function (k) {
        if (k.parentNode.nodeName === "Key") info.keys.push(k.getAttribute("Name"));
      });
      types[t.getAttribute("Name")] = info;
    });
    Array.prototype.forEach.call(doc.getElementsByTagName("EntitySet"), function (s) {
      sets[s.getAttribute("Name")] = types[s.getAttribute("EntityType").split(".").pop()];
    });
  }
  function keyUri(set, row) {
    var info = sets[set];
    var parts = info.keys.map(function (k) {
      var v = info.types[k] === "Edm.String" ? "'" + encodeURIComponent(String(row[k]).replace(/'/g, "''")) + "'" : row[k];
      return info.keys.length > 1 ? k + "=" + v : v;
    });
    return SERVICE_URI + set + "(" + parts.join(",") + ")";
  }
  // MockServer needs complete rows: it answers 404 for a whole table when one row lacks a selected property
  // (a row created in the app has no empty fields), and rows without __metadata (imported ones) are not shown.
  function normalize() {
    Object.keys(sets).forEach(function (set) {
      var rows = server.getEntitySetData(set), changed = false;
      rows.forEach(function (row) {
        sets[set].props.forEach(function (prop) { if (!(prop in row)) { row[prop] = null; changed = true; } });
        if (!row.__metadata) { var uri = keyUri(set, row); row.__metadata = { id: uri, uri: uri, type: sets[set].type }; changed = true; }
      });
      if (changed) server.setEntitySetData(set, rows);
    });
  }
  // ---- Automatic numbers of THIS app (adapt or delete). The user never types a key: before a row is created,
  // the next number is put into the request. `within` = parent keys the numbering restarts for; `via` = navigation
  // property the child is created through (…/SalesOrders('5000001')/to_Items).
  var NUMBERING = [
    { set: "SalesOrders", field: "SalesOrder", start: 5000001, step: 1 },
    { set: "SalesOrderItems", via: "to_Items", field: "SalesOrderItem", start: 10, step: 10, within: ["SalesOrder"] },
    { set: "ScheduleLines", via: "to_ScheduleLines", field: "ScheduleLine", start: 1, step: 1, within: ["SalesOrder", "SalesOrderItem"] }
  ];
  function assignNumber(oEvent) {
    var xhr = oEvent.getParameter("oXhr"), path = decodeURIComponent(String(xhr.url).split("?")[0]);
    var m = path.slice(path.indexOf(SERVICE_URI) + SERVICE_URI.length).match(/^(\w+)(?:\((.*)\)\/(\w+))?$/);
    if (!m) return;
    var rule = NUMBERING.filter(function (n) { return m[3] ? n.via === m[3] : n.set === m[1]; })[0];
    if (!rule) return;
    var body; try { body = JSON.parse(xhr.requestBody || "{}"); } catch (e) { return; }
    (rule.within || []).forEach(function (key, i) {          // parent keys from the address: ('5000001') or (SalesOrder='5000001',SalesOrderItem='10')
      var named = m[2] && m[2].match(new RegExp("(?:^|,)" + key + "='([^']*)'")), single = m[2] && i === 0 && m[2].match(/^'([^']*)'$/);
      if (named) body[key] = named[1]; else if (single) body[key] = single[1];
    });
    var max = 0, found = false;
    server.getEntitySetData(rule.set).forEach(function (row) {
      if ((rule.within || []).every(function (key) { return String(row[key]) === String(body[key]); })) { found = true; max = Math.max(max, Number(row[rule.field]) || 0); }
    });
    body[rule.field] = String(found ? max + rule.step : rule.start);
    xhr.requestBody = JSON.stringify(body);
  }

  // ---- Business rules of THIS app (adapt or delete). Runs after every change, before the data is saved:
  // item net value = quantity × net price, item currency = order currency, order net value = sum of its items.
  function applyRules() {
    if (!sets.SalesOrders || !sets.SalesOrderItems) return false;
    var changed = false, orders = server.getEntitySetData("SalesOrders"), items = server.getEntitySetData("SalesOrderItems"), byOrder = {}, sum = {};
    orders.forEach(function (o) { byOrder[o.SalesOrder] = o; });
    items.forEach(function (it) {
      var o = byOrder[it.SalesOrder];
      var amount = (Number(it.RequestedQuantity) || 0) * (Number(it.NetPrice) || 0), currency = o && o.TransactionCurrency || it.TransactionCurrency;
      if (it.NetAmount !== amount.toFixed(2) || it.TransactionCurrency !== currency) changed = true;
      it.NetAmount = amount.toFixed(2); it.TransactionCurrency = currency;
      sum[it.SalesOrder] = (sum[it.SalesOrder] || 0) + amount;
    });
    orders.forEach(function (o) { var t = (sum[o.SalesOrder] || 0).toFixed(2); if (o.TotalNetAmount !== t) changed = true; o.TotalNetAmount = t; });
    if (changed) { server.setEntitySetData("SalesOrderItems", items); server.setEntitySetData("SalesOrders", orders); }
    return changed;
  }
  function saveAll() {
    // values computed by the rules are re-read by the screens a moment after the change was answered
    if (applyRules() && model) setTimeout(function () { if (!model.hasPendingChanges()) model.refresh(); }, 400);
    normalize();
    if (!hasAndrut) return;
    Object.keys(sets).forEach(function (set) {
      try { andrut.setData("fe_" + set, JSON.stringify(server.getEntitySetData(set))); } catch (e) {}
    });
  }

  fetch(base + "/metadata.xml").then(function (r) { return r.text(); }).then(function (xml) {
    readSets(xml);
    server = new MockServer({ rootUri: SERVICE_URI });
    MockServer.config({ autoRespond: true, autoRespondAfter: 150 });
    server.simulate(base + "/metadata.xml", { sMockdataBaseUrl: base + "/mockdata", bGenerateMissingMockData: true });
    server.start();
    Object.keys(sets).forEach(function (set) {
      try { var raw = hasAndrut ? andrut.getData("fe_" + set) : null; if (raw) server.setEntitySetData(set, JSON.parse(raw)); } catch (e) {}
    });
    normalize();
    // Save after any change. No entity set filter: a child row created through a navigation property
    // (SalesOrders('5000001')/to_Items) is reported under the parent set. setTimeout: the "after" event fires
    // before the mock data is updated.
    server.attachBefore("POST", assignNumber);
    ["POST", "PUT", "MERGE", "PATCH", "DELETE"].forEach(function (method) {
      server.attachAfter(method, function () { setTimeout(saveAll, 0); });
    });
    sap.ui.require(["sap/ui/core/Component"], function (Component) {
      Component.create({ name: "demo.fe", manifest: true }).then(function (comp) {
        model = comp.getModel();
        document.getElementById("loading").remove();
        new ComponentContainer({ component: comp, height: "100%" }).placeAt("content");
        ready();
        console.log("Fiori Elements ready (SAPUI5 " + sap.ui.version + ")");
      }).catch(fail);
    });
  }).catch(fail);

  // Import rows from own code (CSV import, sync…): importRows("Customers", [{Customer: "10100099", Name: "…"}], false).
  // Rows with an existing key replace the old row; replaceAll = true drops all old rows first. Values must have the
  // types of the mock data (Edm.Decimal as string "12.50", Edm.Int32 as number, Edm.DateTime as "/Date(ms)/").
  // Then refresh the open table: this.extensionAPI.refreshTable() in a controller extension, or location.reload().
  window.importRows = function (set, rows, replaceAll) {
    if (!sets[set]) throw new Error("Unknown entity set " + set + ". Known: " + Object.keys(sets).join(", "));
    var keyOf = function (r) { return sets[set].keys.map(function (k) { return String(r[k]); }).join("|"); };
    var byKey = {}, out = [];
    (replaceAll ? [] : server.getEntitySetData(set)).concat(rows).forEach(function (r) {
      var k = keyOf(r), copy = Object.assign({}, r); delete copy.__metadata;
      if (k in byKey) out[byKey[k]] = copy; else { byKey[k] = out.length; out.push(copy); }
    });
    server.setEntitySetData(set, out);
    saveAll();
    return out.length;
  };
  // Property types and keys of an entity set (from metadata.xml), e.g. for converting imported values.
  window.entitySetInfo = function (set) { return sets[set]; };
  // Current rows of an entity set (copy without __metadata) – for checks with run_js.
  window.getRows = function (set) {
    return server.getEntitySetData(set).map(function (r) { var c = Object.assign({}, r); delete c.__metadata; return c; });
  };

  // ---- Helpers for testing with run_js (they work on UI5 controls, so also on buttons hidden in an overflow menu) ----
  function label(c) {
    try { return (c.getText && c.getText()) || (c.getTitle && c.getTitle()) || (c.getTooltip_AsString && c.getTooltip_AsString()) || ""; }
    catch (e) { return ""; } // some controls throw outside their container
  }
  function visible(c) { try { return c.getVisible ? c.getVisible() : true; } catch (e) { return false; } }
  function unique(list) { return list.filter(function (x, i) { return x && list.indexOf(x) === i; }); }
  function controls(test) { var out = []; ElementRegistry.forEach(function (c) { if (test(c)) out.push(c); }); return out; }
  function matches(c, what) { return c.getId().slice(-what.length) === what || label(c) === what; }
  window.ui5Test = {
    // ui5Test.buttons() -> every button: "id suffix | text | visible | on screen"
    buttons: function () {
      return controls(function (c) { return typeof c.firePress === "function" && c.isA("sap.m.Button"); }).map(function (c) {
        return c.getId().split("--").pop() + " | " + label(c) + " | visible=" + c.getVisible() + " | onScreen=" + !!(c.getDomRef() && c.getDomRef().offsetParent);
      });
    },
    // ui5Test.find("Process") -> controls whose id contains the text or whose label equals it
    find: function (what) {
      return controls(function (c) { return c.getId().indexOf(what) >= 0 || label(c) === what; }).map(function (c) {
        return c.getMetadata().getName() + " " + c.getId().split("--").pop() + " | " + label(c) + " | visible=" + visible(c) + " | onScreen=" + !!(c.getDomRef() && c.getDomRef().offsetParent);
      });
    },
    // ui5Test.press("Import CSV") or ui5Test.press("ImportCsvButton") -> presses the button (id suffix or exact text)
    press: function (what) {
      var found = controls(function (c) { return typeof c.firePress === "function" && c.getVisible() && matches(c, what); });
      if (!found.length) {
        return "no visible button \"" + what + "\". Visible buttons: " + unique(controls(function (c) {
          return typeof c.firePress === "function" && c.isA("sap.m.Button") && c.getVisible();
        }).map(label)).slice(0, 40).join(", ");
      }
      found[0].firePress();
      return "pressed " + found[0].getId().split("--").pop() + (found.length > 1 ? " (first of " + found.length + ")" : "");
    },
    // ui5Test.openRow("P-100") -> opens the first table row that contains the text (navigation to its object page)
    openRow: function (text) {
      var rows = controls(function (c) { return c.isA("sap.m.ColumnListItem") && c.getDomRef() && c.getDomRef().innerText.indexOf(text) >= 0; });
      if (!rows.length) return "no table row contains \"" + text + "\"";
      rows[0].getParent().fireItemPress({ listItem: rows[0] });
      return "opened row " + rows[0].getDomRef().innerText.replace(/\s+/g, " ").trim().slice(0, 80);
    },
    // ui5Test.screen() -> route, open dialogs / message toasts, texts of the visible buttons
    screen: function () {
      var texts = function (sel) { return Array.prototype.map.call(document.querySelectorAll(sel), function (e) { return e.innerText.replace(/\s+/g, " ").trim().slice(0, 200); }); };
      return JSON.stringify({ route: location.hash, dialogs: texts(".sapMDialog"), toasts: texts(".sapMMessageToast"),
        buttonsOnScreen: unique(window.ui5Test.buttons().filter(function (b) { return /onScreen=true/.test(b); }).map(function (b) { return b.split(" | ")[1]; })) });
    }
  };

  // Reset to the rows from mockdata/*.json: call from run_js, then reload the world.
  window.resetMockData = function () { Object.keys(sets).forEach(function (set) { if (hasAndrut) andrut.removeData("fe_" + set); }); };
  // State for the AI (check_world / look_at_world read it).
  window.andrutDescribe = function () {
    return "Fiori Elements V2 (SAPUI5 " + sap.ui.version + "), route: " + (location.hash || "list report") + ", rows: " +
      Object.keys(sets).map(function (s) { return s + "=" + (server ? server.getEntitySetData(s).length : "?"); }).join(", ");
  };
});
