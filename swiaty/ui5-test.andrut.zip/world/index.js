(function () {
  var diag = document.getElementById('diag');
  function row(label, value, cls) {
    var d = document.createElement('div');
    var a = document.createElement('span'); a.textContent = label;
    var b = document.createElement('span'); b.textContent = value; if (cls) b.className = cls;
    d.appendChild(a); d.appendChild(b); diag.appendChild(d); return b;
  }
  function check(label, url, pick) {
    var cell = row(label, 'sprawdzam…');
    var t0 = performance.now();
    fetch(url, { cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return pick ? r.json() : r.text();
    }).then(function (j) {
      cell.textContent = (pick ? pick(j) + ' · ' : 'jest · ') + Math.round(performance.now() - t0) + ' ms';
      cell.className = 'ok';
    }).catch(function (e) {
      cell.textContent = 'brak (' + e.message + ')';
      cell.className = 'bad';
    });
  }
  check('OpenUI5', 'https://sdk.openui5.org/resources/sap-ui-version.json', function (j) { return j.version; });
  check('SAPUI5', 'https://ui5.sap.com/resources/sap-ui-version.json', function (j) { return j.version; });
  check('sap.fe (V4) w SAPUI5', 'https://ui5.sap.com/resources/sap/fe/core/library.js');
  check('Fiori Elements V2 w SAPUI5', 'https://ui5.sap.com/resources/sap/suite/ui/generic/template/library.js');
  row('sap.fe (V4) w OpenUI5', 'nie ma (tylko SAPUI5)');
  row('Ekran', innerWidth + '×' + innerHeight + ' px');
  window.andrutDescribe = function () { return 'Menu testu UI5: ' + diag.innerText.replace(/\n/g, ' | '); };
})();
