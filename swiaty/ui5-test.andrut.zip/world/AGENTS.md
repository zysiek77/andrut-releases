# AGENTS.md – UI5 / Fiori – test

## Cel
Świat testowy: czy biblioteki SAP UI5 działają w Andrucie. Trzy strony, biblioteki ładowane z CDN (telefon musi być online).

## Pliki i architektura
- `index.html` + `index.js` – menu (zwykły HTML, motyw Andruta) i diagnostyka CDN: wersje OpenUI5/SAPUI5, czy jest sap.fe i Fiori Elements V2, czasy odpowiedzi.
- `freestyle.html` + `freestyle.js` – freestyle Fiori na **OpenUI5** (`sdk.openui5.org`), motyw `sap_horizon`. Kontrolki tworzone w JS (bez widoków XML): `sap.m.App` z dwiema stronami – lista (`SearchField`, `sap.m.Select` z kategoriami, `ObjectListItem` ze statusem stanu) i szczegóły (`sap.uxap.ObjectPageLayout`). Okno edycji/dodawania (`sap.m.Dialog` + `SimpleForm` + `StepInput`), usuwanie z `MessageBox.confirm`, `MessageToast`, przełącznik motywu jasny/ciemny (`sap_horizon_dark`).
  Bootstrap: `data-sap-ui-resource-roots='{"demo": "./"}'`, start `module:demo/freestyle`. NIE mapuj korzenia `""` – wtedy `sap/*` szukane są w plikach świata.
- `fe.html` + `fe/` – **Fiori Elements V2** na **SAPUI5** (`ui5.sap.com`; `sap.fe` dla OData V4 jest tylko w SAPUI5, w OpenUI5 go nie ma).
  - `fe/start.js` – uruchamia `sap.ui.core.util.MockServer` (serwis OData V2 udawany w przeglądarce: `fe/localService/metadata.xml` + `mockdata/Products.json`), rejestruje zaślepkę usługi `sap.ushell.ui5service.ShellUIService` (bez Fiori Launchpad Fiori Elements rzuca błąd), potem tworzy komponent `demo.fe`.
  - `fe/manifest.json` – `sap.ui.generic.app`: ListReport → ObjectPage dla `Products`, `loadDataOnAppLaunch: always`.
  - `fe/localService/annotations.xml` – UI.LineItem, SelectionFields, HeaderInfo, HeaderFacets (DataPoint stanu z Criticality), Facets z dwiema FieldGroup. Kolumny z `UI.Importance High` są widoczne na wąskim ekranie.
  - `fe/changes/*.json` – puste pliki zmian flex (bez nich 404 w konsoli). `data-sap-ui-xx-component-preload="off"` – bez prób pobrania Component-preload.js.
  - `data-sap-ui-log-level="fatal"` – UI5 nie zgłasza w konsoli znanych, nieszkodliwych błędów braku Launchpada (usługa Navigation, BootstrapConfig).

## Dane
- `products` (setData) – JSON z produktami freestyle (poza Andrutem localStorage `ui5-products`). Fiori Elements: dane tylko w pamięci MockServera (po przeładowaniu wracają z mockdata).
- log: „otworzył / zapisał / usunął: <nazwa>”. `window.andrutDescribe()` na każdej stronie.

## Ważne decyzje
- Gest „wstecz”: freestyle – `history.pushState` przy szczegółach + `popstate`; Fiori Elements – własna nawigacja przez hash.
- `sap.m.Select`, `Dialog`, `MessageBox` to elementy strony (nie natywne okna) – zgodne z zasadami Andruta.
- Motyw Andruta działa tylko w menu; strony UI5 mają motyw Horizon.
