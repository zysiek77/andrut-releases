// Freestyle Fiori na OpenUI5 – wszystkie kontrolki tworzone w JS (bez widoków XML).
sap.ui.define([
  "sap/m/App", "sap/m/Page", "sap/m/List", "sap/m/ObjectListItem", "sap/m/ObjectAttribute", "sap/m/ObjectStatus",
  "sap/m/SearchField", "sap/m/Select", "sap/ui/core/Item", "sap/m/Toolbar", "sap/m/ToolbarSpacer", "sap/m/Button",
  "sap/m/Dialog", "sap/m/Label", "sap/m/Input", "sap/m/StepInput", "sap/m/MessageToast", "sap/m/MessageBox", "sap/m/Text",
  "sap/ui/layout/form/SimpleForm", "sap/ui/model/json/JSONModel", "sap/ui/model/Filter", "sap/ui/model/FilterOperator",
  "sap/uxap/ObjectPageLayout", "sap/uxap/ObjectPageHeader", "sap/uxap/ObjectPageSection", "sap/uxap/ObjectPageSubSection",
  "sap/ui/core/Theming"
], function (App, Page, List, ObjectListItem, ObjectAttribute, ObjectStatus, SearchField, Select, Item, Toolbar, ToolbarSpacer,
             Button, Dialog, Label, Input, StepInput, MessageToast, MessageBox, Text, SimpleForm, JSONModel, Filter, FilterOperator,
             ObjectPageLayout, ObjectPageHeader, ObjectPageSection, ObjectPageSubSection, Theming) {
  "use strict";
  var t0 = performance.now();
  var hasAndrut = typeof window.andrut !== "undefined";
  var DEFAULT = [
    { id: "P-100", name: "Laptop Kestrel 14", category: "Komputery", price: 4299, stock: 12, supplier: "Nordtech" },
    { id: "P-101", name: "Monitor Vista 27", category: "Monitory", price: 1349, stock: 0, supplier: "Optiline" },
    { id: "P-102", name: "Klawiatura Tactile Pro", category: "Akcesoria", price: 389, stock: 54, supplier: "Keyworks" },
    { id: "P-103", name: "Mysz Glide", category: "Akcesoria", price: 149, stock: 3, supplier: "Keyworks" },
    { id: "P-104", name: "Tablet Note 11", category: "Komputery", price: 2199, stock: 7, supplier: "Nordtech" },
    { id: "P-105", name: "Monitor Arc 34", category: "Monitory", price: 2899, stock: 2, supplier: "Optiline" },
    { id: "P-106", name: "Stacja dokująca Hub8", category: "Akcesoria", price: 599, stock: 18, supplier: "Portix" }
  ];
  function load() {
    try { var s = hasAndrut ? andrut.getData("products") : localStorage.getItem("ui5-products"); if (s) return JSON.parse(s); } catch (e) {}
    return JSON.parse(JSON.stringify(DEFAULT));
  }
  function save() {
    var s = JSON.stringify(model.getProperty("/products"));
    try { if (hasAndrut) andrut.setData("products", s); else localStorage.setItem("ui5-products", s); } catch (e) {}
  }
  function log(t) { try { if (hasAndrut) andrut.log(t); } catch (e) {} }
  function state(stock) { return stock === 0 ? "Error" : stock < 5 ? "Warning" : "Success"; }
  function stateText(stock) { return stock === 0 ? "Brak" : stock < 5 ? "Mało" : "Dostępny"; }
  var fmtPrice = function (p) { return new Intl.NumberFormat("pl-PL", { style: "currency", currency: "PLN" }).format(p || 0); };

  var model = new JSONModel({ products: load(), dark: false });

  // ---- lista ----
  var query = "", category = "";
  var list = new List({ growing: true, growingThreshold: 20, noDataText: "Brak produktów" });
  function applyFilters() {
    var f = [];
    if (query) f.push(new Filter("name", FilterOperator.Contains, query));
    if (category) f.push(new Filter("category", FilterOperator.EQ, category));
    list.getBinding("items").filter(f.length ? new Filter({ filters: f, and: true }) : []);
  }
  list.bindItems({
    path: "/products",
    template: new ObjectListItem({
      title: "{name}", type: "Navigation",
      number: { path: "price", formatter: fmtPrice },
      attributes: [new ObjectAttribute({ text: "{category} · {id}" })],
      firstStatus: new ObjectStatus({ text: { path: "stock", formatter: function (s) { return stateText(s) + " (" + s + " szt.)"; } },
                                       state: { path: "stock", formatter: state } }),
      press: function (e) { openDetail(e.getSource().getBindingContext().getPath()); }
    })
  });
  var catSelect = new Select({
    width: "10rem",
    items: [new Item({ key: "", text: "Wszystkie" }), new Item({ key: "Komputery", text: "Komputery" }),
            new Item({ key: "Monitory", text: "Monitory" }), new Item({ key: "Akcesoria", text: "Akcesoria" })],
    change: function (e) { category = e.getParameter("selectedItem").getKey(); applyFilters(); }
  });
  var listPage = new Page("listPage", {
    title: "Produkty",
    showNavButton: true,
    navButtonPress: function () { location.href = "index.html"; },
    subHeader: new Toolbar({ content: [
      new SearchField({ width: "100%", placeholder: "Szukaj produktu", liveChange: function (e) { query = e.getParameter("newValue"); applyFilters(); } })
    ] }),
    content: [new Toolbar({ content: [new Label({ text: "Kategoria:" }), catSelect, new ToolbarSpacer()] }), list],
    headerContent: [
      new Button({ icon: "sap-icon://add", tooltip: "Dodaj", press: function () { openEdit(null); } }),
      new Button({ icon: "sap-icon://light-mode", tooltip: "Motyw", press: toggleTheme })
    ]
  });

  // ---- szczegóły (ObjectPage) ----
  var currentPath = null;
  var header = new ObjectPageHeader({
    objectTitle: "{name}", objectSubtitle: "{category} · {id}",
    actions: [
      new Button({ text: "Edytuj", type: "Emphasized", press: function () { openEdit(currentPath); } }),
      new Button({ text: "Usuń", type: "Reject", press: function () { confirmDelete(); } })
    ]
  });
  var info = new SimpleForm({ editable: false, layout: "ResponsiveGridLayout", content: [
    new Label({ text: "Cena" }), new Text({ text: { path: "price", formatter: fmtPrice } }),
    new Label({ text: "Stan" }), new ObjectStatus({ text: { path: "stock", formatter: function (s) { return stateText(s) + " (" + s + " szt.)"; } }, state: { path: "stock", formatter: state } }),
    new Label({ text: "Dostawca" }), new Text({ text: "{supplier}" })
  ] });
  var objectPage = new ObjectPageLayout({
    headerTitle: header,
    sections: [
      new ObjectPageSection({ title: "Informacje", subSections: [new ObjectPageSubSection({ blocks: [info] })] }),
      new ObjectPageSection({ title: "Uwagi", subSections: [new ObjectPageSubSection({ blocks: [
        new Text({ text: "To jest ObjectPageLayout z biblioteki sap.uxap – typowy ekran szczegółów w stylu Fiori." })
      ] })] })
    ]
  });
  var detailPage = new Page("detailPage", {
    title: "Szczegóły", showNavButton: true, navButtonPress: function () { history.back(); },
    content: [objectPage], enableScrolling: false
  });

  var app = new App({ pages: [listPage, detailPage] });
  app.setModel(model);

  function openDetail(path, fromHistory) {
    currentPath = path;
    detailPage.bindElement(path);
    app.to(detailPage);
    if (!fromHistory) history.pushState({ detail: path }, "");
    log("otworzył: " + model.getProperty(path + "/name"));
  }
  // gest „wstecz” Androida wraca z szczegółów do listy
  window.addEventListener("popstate", function (e) {
    if (e.state && e.state.detail) openDetail(e.state.detail, true);
    else if (app.getCurrentPage() === detailPage) app.back();
  });

  // ---- okno edycji / dodawania ----
  function openEdit(path) {
    var src = path ? model.getProperty(path) : { id: "P-" + (100 + model.getProperty("/products").length + Math.floor(Math.random() * 900)), name: "", category: "Akcesoria", price: 0, stock: 0, supplier: "" };
    var draft = new JSONModel(JSON.parse(JSON.stringify(src)));
    var dlg = new Dialog({
      title: path ? "Edytuj produkt" : "Nowy produkt", contentWidth: "22rem",
      content: [new SimpleForm({ editable: true, layout: "ResponsiveGridLayout", content: [
        new Label({ text: "Nazwa", required: true }), new Input({ value: "{d>/name}" }),
        new Label({ text: "Kategoria" }), new Select({ selectedKey: "{d>/category}", items: [
          new Item({ key: "Komputery", text: "Komputery" }), new Item({ key: "Monitory", text: "Monitory" }), new Item({ key: "Akcesoria", text: "Akcesoria" })] }),
        new Label({ text: "Cena (zł)" }), new StepInput({ value: "{d>/price}", min: 0, step: 10, displayValuePrecision: 0 }),
        new Label({ text: "Stan (szt.)" }), new StepInput({ value: "{d>/stock}", min: 0 }),
        new Label({ text: "Dostawca" }), new Input({ value: "{d>/supplier}" })
      ] })],
      beginButton: new Button({ text: "Zapisz", type: "Emphasized", press: function () {
        var d = draft.getData();
        if (!d.name.trim()) { MessageToast.show("Podaj nazwę"); return; }
        if (path) model.setProperty(path, d);
        else { var arr = model.getProperty("/products"); arr.push(d); model.setProperty("/products", arr); }
        save(); dlg.close(); MessageToast.show("Zapisano: " + d.name); log("zapisał: " + d.name);
      } }),
      endButton: new Button({ text: "Anuluj", press: function () { dlg.close(); } }),
      afterClose: function () { dlg.destroy(); }
    });
    dlg.setModel(draft, "d");
    dlg.open();
  }
  function confirmDelete() {
    var p = model.getProperty(currentPath);
    MessageBox.confirm("Usunąć „" + p.name + "”?", { title: "Usuwanie", actions: ["Usuń", MessageBox.Action.CANCEL], emphasizedAction: "Usuń",
      onClose: function (a) {
        if (a !== "Usuń") return;
        var arr = model.getProperty("/products").filter(function (x) { return x.id !== p.id; });
        model.setProperty("/products", arr); save(); history.back(); MessageToast.show("Usunięto"); log("usunął: " + p.name);
      } });
  }
  function toggleTheme() {
    var dark = !model.getProperty("/dark"); model.setProperty("/dark", dark);
    Theming.setTheme(dark ? "sap_horizon_dark" : "sap_horizon");
  }

  window.andrutDescribe = function () {
    return "Freestyle OpenUI5 " + sap.ui.version + ": " + model.getProperty("/products").length + " produktów, ekran: " +
      (app.getCurrentPage() === detailPage ? "szczegóły " + (currentPath && model.getProperty(currentPath + "/name")) : "lista") +
      ", motyw: " + Theming.getTheme();
  };

  document.getElementById("loading").remove();
  app.placeAt("content");
  console.log("OpenUI5 " + sap.ui.version + " gotowe po " + Math.round(performance.now() - t0) + " ms od startu modułu");
});
