// Start: najpierw MockServer (udaje serwis OData V2 w przeglądarce), potem komponent Fiori Elements.
sap.ui.define([
  "sap/ui/core/util/MockServer", "sap/ui/core/ComponentContainer",
  "sap/ui/core/service/Service", "sap/ui/core/service/ServiceFactory", "sap/ui/core/service/ServiceFactoryRegistry"
], function (MockServer, ComponentContainer, Service, ServiceFactory, ServiceFactoryRegistry) {
  "use strict";
  // Bez Fiori Launchpad: zaślepka usługi powłoki (tytuł, nawigacja wstecz), o którą prosi Fiori Elements.
  var ShellStub = Service.extend("demo.fe.ShellUIServiceStub", {
    setTitle: function (t) { document.title = t; }, getTitle: function () { return document.title; },
    setHierarchy: function () {}, setRelatedApps: function () {}, setBackNavigation: function () {},
    attachEvent: function () {}, detachEvent: function () {}
  });
  ServiceFactoryRegistry.register("sap.ushell.ui5service.ShellUIService", new ServiceFactory(ShellStub));
  var t0 = performance.now();
  var base = sap.ui.require.toUrl("demo/fe/localService");
  var server = new MockServer({ rootUri: "/sap/opu/odata/sap/ZDEMO_PRODUCTS_SRV/" });
  MockServer.config({ autoRespond: true, autoRespondAfter: 150 });
  server.simulate(base + "/metadata.xml", { sMockdataBaseUrl: base + "/mockdata", bGenerateMissingMockData: true });
  server.start();
  sap.ui.require(["sap/ui/core/Component"], function (Component) {
    Component.create({ name: "demo.fe", manifest: true }).then(function (comp) {
      document.getElementById("loading").remove();
      new ComponentContainer({ component: comp, height: "100%" }).placeAt("content");
      console.log("SAPUI5 " + sap.ui.version + " + Fiori Elements V2 gotowe po " + Math.round(performance.now() - t0) + " ms");
    }).catch(function (e) {
      document.getElementById("loading").textContent = "Błąd startu Fiori Elements: " + e.message;
      console.error("Fiori Elements: " + (e.stack || e.message));
    });
  });
  window.andrutDescribe = function () {
    return "Fiori Elements V2 (SAPUI5 " + sap.ui.version + "), adres: " + location.hash;
  };
});
