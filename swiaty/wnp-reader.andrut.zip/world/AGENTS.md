# AGENTS.md – wnp.pl reader

## Cel i ustalenia
Czytelnik nagłówków wnp.pl (RSS) + scrapper pełnej treści artykułów. Mobile-first, jasny motyw Clean Light, bez przewijania w poziomie. Zdzisiu.

## Pliki i architektura
- `index.html` – szkielet: topbar (← wstecz, logo, ↻ odśwież), poziomy pasek działów (chipy), ekran listy, ekran artykułu. Ładuje `/theme/andrut-theme.css`.
- `style.css` – layout flex 100dvh, karty (siatka 1/2/3 kolumny wg szerokości), skeletony, chipy. Tylko zmienne motywu.
- `app.js` – cała logika (IIFE): pobieranie i parsowanie RSS, cache, render, scrapper, historia.

Działy (id → RSS `https://www.wnp.pl/rss/<id>_rss.xml`): serwis (wszystko, ~300 pozycji), energia, przemysl, rynki, tech, bezpieczenstwo, budownictwo, logistyka, polityka-i-sondaze (działy mają po ~10 pozycji – tyle daje ich RSS).

Pobieranie RSS (`fetchList`): równolegle `Promise.any` po pełnym RSS: 1) `r.jina.ai/<rss>` z nagłówkiem `X-Return-Format: html` (najszybsze, ~2 s; bez nagłówka jina spłaszcza XML do tekstu!), 2) `api.allorigins.win/raw` (wolne, ~20 s), 3) `api.codetabs.com/v1/proxy` (często 522). 4) `api.rss2json.com` – tylko 10 pozycji, więc to zapas: użyty, gdy pełne zawiodą albo milczą > 6 s. 5) Awaryjnie markdown strony działu przez `r.jina.ai` (`parseJinaListing` – filtry `BAD_LINK`, tylko linki `,<id>.html`).
Parser XML napisany ręcznie (regex + `xmlUnescape`), bo DOMParser nie radzi sobie z tekstem z proxy. Jina w trybie html zamienia CDATA na `<!--[CDATA[…]]-->` i `<link>` na pusty element (adres stoi za nim) – parser to obsługuje. `pubDate` wnp.pl nie ma strefy → traktowane jako czas Europe/Warsaw (`parseDate`).
Bezpośrednie `fetch` do wnp.pl jest blokowane przez CORS – nigdy go nie używaj. Obrazki (`pliki.wnp.pl`) ładują się zwykłym `<img>` bez problemu.

Scrapper artykułu (`scrape`): po kolei jina (html) → codetabs → allorigins → jina (markdown, `extractMarkdown`). `extractHtml`: kontener z największą sumą tekstu `<p>` z listy SELECTORS (na wnp.pl wygrywa `.post-content`), wcześniej usuwa śmieci (`JUNK_SEL`: boksy nrb, „Czytaj więcej”, copyright, ticker, stopka, komentarze, banery); bierze `p, h2, h3` w kolejności, filtr `JUNK_TEXT` i krótkie etykiety. Lead z `.post-lead`, data z `time[itemprop=datePublished]`, zdjęcie z `og:image`.

## Dane (klucze setData) i zdarzenia (log)
- `cat` – wybrany dział (id).
- `read` – JSON tablica linków przeczytanych (max 400).
- `cache_<id>` – `{ts, timeStr, items[40]}` cache na 10 min (świeży = bez pobierania; starszy = pokazany od razu i odświeżany w tle).
- log: „wybrał dział: X”, „otworzył: <tytuł>”, „odświeżył: X”.
- `window.andrutDescribe()` – dział, liczba pozycji, liczba przeczytanych, otwarty artykuł.

## Ważne decyzje
- Wszystko renderowane przez `textContent` (bez innerHTML z danymi) – bezpieczeństwo. HTML artykułu parsowany DOMParserem tylko do odczytu tekstu.
- Widok artykułu to stan w historii (`history.pushState` + `popstate`), więc gest „wstecz” wraca do listy. Przycisk ← robi `history.back()`.
- Twarde ograniczenia: height 100dvh, overflow hidden na body, przewija się tylko `#screen-list` / `#screen-article` (chipy przewijają się w poziomie tylko wewnątrz paska).
- `loadSeq` / `articleSeq` – spóźniona odpowiedź nie nadpisze nowszego widoku.
- ↻ na liście = wymuszone odświeżenie działu; w artykule = ponowne pobranie treści.

## Znane problemy i obejścia
- Publiczne proxy CORS bywają niedostępne (allorigins 522/wolne, codetabs 522, corsproxy 401) – dlatego łańcuch awaryjny i cache.
- Wcześniejsze 404 na `app.js` = plik nie istniał; po dodaniu pliku błędy zniknęły.

## Do zrobienia
- Ewentualnie: wyszukiwarka w obrębie listy, tryb „zapisz na później”, powiadomienia o nowych newsach.

## Dziennik zmian (najnowsze na górze)
- 2026-11-06 – pierwsza pełna wersja świata (lista z cache, działy, artykuł ze scrapperem, historia, przeczytane). Przetestowana na żywych danych: RSS przez jina (html), artykuły z `.post-content`, awaryjny parser strony działu (54 linki z /energia/).
