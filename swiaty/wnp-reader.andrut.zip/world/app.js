/* wnp.pl – czytnik nagłówków (RSS) + scrapper treści artykułów. Opis: AGENTS.md */
(function () {
  'use strict';

  // ---------- most Andruta (z zapasem dla zwykłej przeglądarki) ----------
  const A = window.andrut || {
    getData: k => { try { return localStorage.getItem('wnp_' + k); } catch (e) { return null; } },
    setData: (k, v) => { try { localStorage.setItem('wnp_' + k, v); } catch (e) {} },
    removeData: k => { try { localStorage.removeItem('wnp_' + k); } catch (e) {} },
    log: t => console.log('[log]', t),
  };
  const getJSON = (k, d) => { try { const v = A.getData(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const setJSON = (k, v) => { try { A.setData(k, JSON.stringify(v)); } catch (e) {} };
  const log = t => { try { A.log(t); } catch (e) {} };

  // ---------- konfiguracja ----------
  const CATS = [
    { id: 'serwis', name: 'Wszystko' },
    { id: 'energia', name: 'Energia' },
    { id: 'przemysl', name: 'Przemysł' },
    { id: 'rynki', name: 'Rynki' },
    { id: 'tech', name: 'Tech' },
    { id: 'bezpieczenstwo', name: 'Bezpieczeństwo' },
    { id: 'budownictwo', name: 'Budownictwo' },
    { id: 'logistyka', name: 'Logistyka' },
    { id: 'polityka-i-sondaze', name: 'Polityka i sondaże' },
  ];
  const rssUrl = id => `https://www.wnp.pl/rss/${id}_rss.xml`;
  const pageUrl = id => id === 'serwis' ? 'https://www.wnp.pl/' : `https://www.wnp.pl/${id}/`;
  const CACHE_MS = 10 * 60 * 1000;
  const MAX_ITEMS = 40;
  const MAX_READ = 400;
  const TIMEOUT = 15000;
  const BAD_LINK = /\/(tagi|autor|szukaj|rss|newsletter|kontakt|regulamin|reklama|wideo|galeria)\b/i;
  // kandydaci na kontener treści (wygrywa ten z największą sumą tekstu <p>)
  const SELECTORS = ['.post-content', '[itemprop="articleBody"]', '.article-content', '.article__content', 'article', 'main'];
  const JUNK_SEL = 'script, style, noscript, iframe, form, figure, aside, [class*="nrb-box"], .post-read-more, .post-copyright, .post-summary, .ticker, .post-footer, .post-comments-cnt, [class*="banner"], [class*="sad-"], [class*="newsletter"]';
  const JUNK_TEXT = /^(czytaj (też|także|więcej)|zobacz (też|także)|polecamy|reklama|newsletter|udostępnij|©|tagi:)/i;

  // ---------- stan ----------
  const $ = id => document.getElementById(id);
  let cat = CATS.some(c => c.id === A.getData('cat')) ? A.getData('cat') : 'serwis';
  let items = [];
  let readSet = new Set(getJSON('read', []));
  let current = null;      // otwarty artykuł {title, link, ...}
  let loadSeq = 0;         // chroni przed nadpisaniem listy przez spóźnioną odpowiedź
  let articleSeq = 0;

  // ---------- sieć ----------
  async function get(url, opts = {}) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), opts.timeout || TIMEOUT);
    try {
      const r = await fetch(url, { signal: ctl.signal, headers: opts.headers || {} });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return await r.text();
    } finally { clearTimeout(t); }
  }
  const jina = (u, fmt) => get('https://r.jina.ai/' + u, fmt ? { headers: { 'X-Return-Format': fmt } } : {});
  const allorigins = u => get('https://api.allorigins.win/raw?url=' + encodeURIComponent(u));
  const codetabs = u => get('https://api.codetabs.com/v1/proxy?quest=' + encodeURIComponent(u));

  // ---------- parsowanie RSS (ręcznie – tekst z proxy bywa „zepsutym” XML/HTML) ----------
  function xmlUnescape(s) {
    return String(s || '')
      .replace(/<!(?:--)?\[CDATA\[([\s\S]*?)\]\](?:--)?>?/g, '$1')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
      .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
      .replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&apos;|&#39;/g, "'")
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
      .replace(/\s+/g, ' ').trim();
  }
  function tag(block, name) {
    const m = block.match(new RegExp(`<${name}\\b[^>]*>([\\s\\S]*?)</${name}>`, 'i'));
    return m ? m[1] : '';
  }
  function parseRss(xml) {
    const out = [];
    const blocks = String(xml).match(/<item\b[\s\S]*?<\/item>/gi) || [];
    for (const b of blocks) {
      const title = xmlUnescape(tag(b, 'title'));
      // jina (tryb html) zamienia <link> na pusty element – adres zostaje tuż za nim
      let link = xmlUnescape(tag(b, 'link'));
      if (!/^https?:/.test(link)) link = (b.match(/<link\s*\/?>\s*(https?:\/\/[^\s<]+)/i) || [])[1] || xmlUnescape(tag(b, 'guid'));
      const img = (b.match(/<enclosure[^>]*url="([^"]+)"/i) || [])[1] || xmlUnescape(tag(b, 'img')) || '';
      if (!title || !/^https?:\/\/(www\.)?wnp\.pl\//.test(link)) continue;
      out.push({ title, link, img, desc: xmlUnescape(tag(b, 'description')), date: parseDate(xmlUnescape(tag(b, 'pubDate'))) });
    }
    if (!out.length) throw new Error('brak pozycji w RSS');
    return out;
  }
  // pubDate wnp.pl nie ma strefy („Thu, 05 Nov 2026 21:24:00”) – to czas polski
  function parseDate(s) {
    if (!s) return 0;
    const hasZone = /([+-]\d{4}|GMT|UTC|Z)\s*$/i.test(s);
    let t = Date.parse(hasZone ? s : s.replace(' ', 'T'));
    if (isNaN(t)) t = Date.parse(s);
    if (isNaN(t)) return 0;
    if (!hasZone) t += new Date(t).getTimezoneOffset() * 60000 + warsawOffset(t) * 60000;
    return t;
  }
  function warsawOffset(t) { // minuty na wschód od UTC (zima 60, lato 120)
    try {
      const p = new Intl.DateTimeFormat('en-US', { timeZone: 'Europe/Warsaw', timeZoneName: 'shortOffset' }).formatToParts(new Date(t));
      const m = (p.find(x => x.type === 'timeZoneName') || {}).value.match(/GMT([+-]\d+)/);
      return m ? +m[1] * 60 : 60;
    } catch (e) { return 60; }
  }
  function parseRss2Json(txt) {
    const j = JSON.parse(txt);
    if (j.status !== 'ok' || !j.items || !j.items.length) throw new Error('rss2json: ' + (j.message || 'pusto'));
    return j.items.map(i => ({
      title: xmlUnescape(i.title), link: i.link, img: (i.enclosure && i.enclosure.link) || i.thumbnail || '',
      desc: xmlUnescape(i.description), date: parseDate(i.pubDate),
    }));
  }
  // awaryjnie: markdown strony działu z r.jina.ai
  function parseJinaListing(md) {
    const text = String(md).replace(/!\[[^\]]*\]\([^)]*\)/g, ' ');
    const seen = new Set(), out = [];
    const re = /\[([^\]]{12,300})\]\((https?:\/\/(?:www\.)?wnp\.pl\/[^)\s]*,\d+\.html)[^)]*\)/g;
    let m;
    while ((m = re.exec(text))) {
      const link = m[2], title = m[1].replace(/[*_#`]/g, '').replace(/\s+/g, ' ').trim();
      if (seen.has(link) || BAD_LINK.test(link) || title.split(' ').length < 3) continue;
      seen.add(link);
      out.push({ title, link, img: '', desc: '', date: 0 });
    }
    if (out.length < 3) throw new Error('za mało linków na stronie');
    return out;
  }

  async function fetchList(id) {
    const u = rssUrl(id);
    // pełny RSS (do 300 pozycji) ma pierwszeństwo; rss2json daje tylko 10 – zapas, gdy pełne zawiodą lub milczą > 6 s
    const full = Promise.any([
      jina(u, 'html').then(t => ({ items: parseRss(t), src: 'jina' })),
      allorigins(u).then(t => ({ items: parseRss(t), src: 'allorigins' })),
      codetabs(u).then(t => ({ items: parseRss(t), src: 'codetabs' })),
    ]);
    const lite = get('https://api.rss2json.com/v1/api.json?rss_url=' + encodeURIComponent(u)).then(t => ({ items: parseRss2Json(t), src: 'rss2json' }));
    lite.catch(() => {});
    const liteFallback = new Promise((res, rej) => {
      full.catch(() => lite.then(res, rej));
      setTimeout(() => lite.then(res, () => {}), 6000);
    });
    try { return await Promise.any([full, liteFallback]); }
    catch (e) {
      const t = await jina(pageUrl(id));
      return { items: parseJinaListing(t), src: 'strona działu' };
    }
  }

  // ---------- lista ----------
  function timeStr(ts) { return new Date(ts).toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' }); }
  function ago(ts) {
    if (!ts) return '';
    const d = Date.now() - ts, min = Math.round(d / 60000);
    if (min < 1) return 'przed chwilą';
    if (min < 60) return `${min} min temu`;
    if (min < 6 * 60) return `${Math.floor(min / 60)} godz. temu`;
    const dt = new Date(ts), today = new Date();
    const y = new Date(); y.setDate(today.getDate() - 1);
    if (dt.toDateString() === today.toDateString()) return 'dziś ' + timeStr(ts);
    if (dt.toDateString() === y.toDateString()) return 'wczoraj ' + timeStr(ts);
    return dt.toLocaleDateString('pl-PL', { day: 'numeric', month: 'short' }) + ' ' + timeStr(ts);
  }
  const catName = id => (CATS.find(c => c.id === id) || CATS[0]).name;
  const sectionOf = link => { const m = link.match(/wnp\.pl\/([^/]+)\//); return m ? catName(m[1]) !== 'Wszystko' ? catName(m[1]) : '' : ''; };

  function el(tagName, cls, text) {
    const e = document.createElement(tagName);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function setStatus(text, err) { const s = $('status'); s.textContent = text; s.classList.toggle('err', !!err); }
  function spinning(on) { $('btn-refresh').classList.toggle('spin', on); }

  function renderCats() {
    const box = $('cats');
    box.textContent = '';
    for (const c of CATS) {
      const b = el('button', 'chip' + (c.id === cat ? ' active' : ''), c.name);
      b.type = 'button';
      b.onclick = () => selectCat(c.id);
      box.appendChild(b);
    }
    const act = box.querySelector('.active');
    if (act) act.scrollIntoView({ inline: 'center', block: 'nearest' });
  }

  function renderSkeleton() {
    const list = $('list');
    list.textContent = '';
    for (let i = 0; i < 6; i++) {
      const it = el('div', 'item skeleton');
      it.appendChild(el('div', 'thumb sk'));
      const body = el('div', 'body');
      for (const w of ['95%', '80%', '40%']) { const l = el('div', 'sk sk-line'); l.style.width = w; body.appendChild(l); }
      it.appendChild(body);
      list.appendChild(it);
    }
  }

  function renderList() {
    const list = $('list');
    list.textContent = '';
    if (!items.length) {
      const e = el('div', 'empty', 'Brak wiadomości.');
      list.appendChild(e);
      return;
    }
    for (const it of items) {
      const card = el('div', 'item' + (readSet.has(it.link) ? ' read' : ''));
      card.setAttribute('role', 'button');
      if (it.img) {
        const img = el('img', 'thumb');
        img.loading = 'lazy'; img.alt = ''; img.src = it.img;
        img.onerror = () => img.remove();
        card.appendChild(img);
      }
      const body = el('div', 'body');
      body.appendChild(el('h3', null, it.title));
      if (it.desc) body.appendChild(el('p', 'desc', it.desc));
      const meta = [cat === 'serwis' ? sectionOf(it.link) : '', ago(it.date)].filter(Boolean).join(' · ');
      if (meta) body.appendChild(el('div', 'meta', meta));
      card.appendChild(body);
      card.onclick = () => openArticle(it, true);
      list.appendChild(card);
    }
  }

  function renderError(msg) {
    const list = $('list');
    list.textContent = '';
    const e = el('div', 'empty');
    e.appendChild(el('div', null, 'Nie udało się pobrać wiadomości.'));
    e.appendChild(el('div', 'muted', msg));
    const b = el('button', null, 'Spróbuj ponownie');
    b.onclick = () => load(true);
    e.appendChild(b);
    list.appendChild(e);
  }

  async function load(force) {
    const id = cat, seq = ++loadSeq;
    const cached = getJSON('cache_' + id, null);
    const fresh = cached && Date.now() - cached.ts < CACHE_MS;
    if (cached && cached.items && cached.items.length) {
      items = cached.items; renderList();
      setStatus(`${catName(id)} · zaktualizowano ${cached.timeStr}${fresh && !force ? '' : ' · odświeżam…'}`);
      if (fresh && !force) return;
    } else {
      items = []; renderSkeleton(); setStatus(`${catName(id)} · pobieram…`);
    }
    spinning(true);
    try {
      const r = await fetchList(id);
      if (seq !== loadSeq) return;
      const list = r.items.sort((a, b) => b.date - a.date).slice(0, MAX_ITEMS);
      const ts = Date.now();
      setJSON('cache_' + id, { ts, timeStr: timeStr(ts), items: list });
      items = list; renderList();
      setStatus(`${catName(id)} · ${list.length} wiadomości · ${timeStr(ts)} · źródło: ${r.src}`);
    } catch (e) {
      if (seq !== loadSeq) return;
      const msg = (e && e.errors ? e.errors.map(x => x.message).join('; ') : e && e.message) || String(e);
      if (items.length) setStatus(`Nie udało się odświeżyć – pokazuję zapisane (${cached.timeStr})`, true);
      else { setStatus('Błąd pobierania', true); renderError(msg); }
      console.warn('wnp: lista', msg);
    } finally {
      if (seq === loadSeq) spinning(false);
    }
  }

  function selectCat(id) {
    if (id === cat && !current) return;
    cat = id;
    A.setData('cat', id);
    log('wybrał dział: ' + catName(id));
    if (current) history.back();
    renderCats();
    $('screen-list').scrollTop = 0;
    load(false);
  }

  // ---------- artykuł (scrapper) ----------
  function textOf(n) { return (n.textContent || '').replace(/\s+/g, ' ').trim(); }
  function pScore(n) { let s = 0; n.querySelectorAll('p').forEach(p => { s += textOf(p).length; }); return s; }

  function extractHtml(html, url) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const meta = n => { const m = doc.querySelector(`meta[property="${n}"], meta[name="${n}"]`); return m ? m.getAttribute('content') || '' : ''; };
    let best = null, bestScore = 0;
    for (const sel of SELECTORS) {
      doc.querySelectorAll(sel).forEach(c => {
        const clone = c.cloneNode(true);
        clone.querySelectorAll(JUNK_SEL).forEach(j => j.remove());
        const s = pScore(clone);
        if (s > bestScore) { best = clone; bestScore = s; }
      });
    }
    if (!best || bestScore < 200) { // heurystyka: rodzic z największą sumą <p>
      const sums = new Map();
      doc.querySelectorAll('p').forEach(p => { const par = p.parentElement; if (par) sums.set(par, (sums.get(par) || 0) + textOf(p).length); });
      for (const [par, s] of sums) if (s > bestScore) { best = par.cloneNode(true); bestScore = s; }
      if (best) best.querySelectorAll(JUNK_SEL).forEach(j => j.remove());
    }
    const blocks = [];
    if (best) best.querySelectorAll('p, h2, h3').forEach(n => {
      const t = textOf(n);
      if (!t || JUNK_TEXT.test(t)) return;
      if (n.tagName === 'P' && t.length < 25 && !/[.!?:"”]$/.test(t)) return;
      if (n.tagName !== 'P' && t.length > 160) return;
      if (n.tagName === 'P' && n.querySelector('p')) return;
      blocks.push({ h: n.tagName !== 'P', t });
    });
    const leadEl = doc.querySelector('.post-lead, [itemprop="description"]');
    const timeEl = doc.querySelector('time[datetime], [itemprop="datePublished"]');
    const h1 = doc.querySelector('h1');
    return {
      title: meta('og:title') || (h1 && textOf(h1)) || '',
      lead: (leadEl && textOf(leadEl)) || meta('og:description') || '',
      img: meta('og:image'),
      date: timeEl ? Date.parse(timeEl.getAttribute('datetime') || timeEl.getAttribute('content') || '') || 0 : 0,
      blocks, url,
    };
  }

  function extractMarkdown(md, url) {
    const body = String(md).split('Markdown Content:').pop();
    const blocks = [];
    for (let line of body.split(/\n+/)) {
      line = line.trim();
      if (!line || /^!\[/.test(line) || /^[*\-+|>]/.test(line) || /^\[.*\]\(.*\)$/.test(line)) continue;
      const head = /^#{2,3}\s+/.test(line);
      const t = line.replace(/^#+\s*/, '').replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/[*_`]/g, '').trim();
      if (JUNK_TEXT.test(t)) continue;
      if (head ? t.length > 3 && t.length < 160 : t.length >= 60) blocks.push({ h: head, t });
    }
    return { title: '', lead: '', img: '', date: 0, blocks, url };
  }

  async function scrape(url) {
    const html = t => { const a = extractHtml(t, url); if (a.blocks.length < 2) throw new Error('nie znaleziono treści'); return a; };
    const steps = [
      () => jina(url, 'html').then(html),
      () => codetabs(url).then(html),
      () => allorigins(url).then(html),
      () => jina(url).then(t => { const a = extractMarkdown(t, url); if (a.blocks.length < 2) throw new Error('pusta treść'); return a; }),
    ];
    const errs = [];
    for (const s of steps) { try { return await s(); } catch (e) { errs.push(e.message || String(e)); } }
    throw new Error(errs.join('; '));
  }

  function showScreen(article) {
    $('screen-list').hidden = article;
    $('screen-article').hidden = !article;
    $('btn-back').hidden = !article;
    $('logo-sub').textContent = article ? catName(cat) : 'czytnik';
  }

  function renderArticle(it, a, loading, err) {
    const box = $('article');
    box.textContent = '';
    box.appendChild(el('h1', null, (a && a.title) || it.title));
    const date = (a && a.date) || it.date;
    const meta = [sectionOf(it.link), date ? new Date(date).toLocaleString('pl-PL', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) : ''].filter(Boolean).join(' · ');
    if (meta) box.appendChild(el('div', 'meta', meta));
    const imgSrc = (a && a.img) || it.img;
    if (imgSrc) { const img = el('img', 'hero'); img.alt = ''; img.src = imgSrc; img.onerror = () => img.remove(); box.appendChild(img); }
    const lead = (a && a.lead) || it.desc;
    if (lead) box.appendChild(el('p', 'lead', lead));
    if (loading) {
      for (const w of ['100%', '96%', '92%', '98%', '70%', '100%', '88%']) { const l = el('div', 'sk sk-line'); l.style.width = w; box.appendChild(l); }
    } else if (a) {
      a.blocks.forEach(b => { if (!lead || b.t !== lead) box.appendChild(el(b.h ? 'h2' : 'p', null, b.t)); });
    }
    if (err) box.appendChild(el('p', 'note', 'Nie udało się pobrać pełnej treści (' + err + '). Możesz otworzyć artykuł na wnp.pl.'));
    const src = el('div', 'src');
    const open = el('button', 'secondary', 'Otwórz na wnp.pl');
    open.onclick = () => { window.open(it.link, '_blank'); };
    src.appendChild(open);
    if (err) { const retry = el('button', null, 'Spróbuj ponownie'); retry.onclick = () => openArticle(it, false); src.appendChild(retry); }
    box.appendChild(src);
  }

  async function openArticle(it, push) {
    current = it;
    if (push) {
      history.pushState({ a: it.link }, '');
      log('otworzył: ' + it.title);
    }
    if (!readSet.has(it.link)) {
      readSet.add(it.link);
      const arr = [...readSet].slice(-MAX_READ);
      readSet = new Set(arr);
      setJSON('read', arr);
    }
    showScreen(true);
    $('screen-article').scrollTop = 0;
    const seq = ++articleSeq;
    renderArticle(it, null, true);
    try {
      const a = await scrape(it.link);
      if (seq === articleSeq && current === it) renderArticle(it, a, false);
    } catch (e) {
      console.warn('wnp: artykuł', e.message);
      if (seq === articleSeq && current === it) renderArticle(it, null, false, 'serwery pośredniczące nie odpowiedziały');
    }
  }

  function closeArticle() {
    current = null;
    articleSeq++;
    showScreen(false);
    renderList(); // odśwież oznaczenie przeczytanych
  }

  // ---------- zdarzenia ----------
  window.addEventListener('popstate', e => {
    if (e.state && e.state.a) {
      const it = items.find(i => i.link === e.state.a);
      if (it) { openArticle(it, false); return; }
    }
    if (current) closeArticle();
  });
  $('btn-back').onclick = () => history.back();
  $('btn-refresh').onclick = () => {
    if (current) { openArticle(current, false); return; }
    log('odświeżył: ' + catName(cat));
    load(true);
  };

  window.andrutDescribe = () => {
    const base = `Dział: ${catName(cat)}; pozycji na liście: ${items.length}; przeczytanych łącznie: ${readSet.size}.`;
    return current ? `${base} Otwarty artykuł: „${current.title}” (${current.link}).` : base + ' Widok: lista.';
  };

  // ---------- start ----------
  history.replaceState({}, '');
  renderCats();
  load(false);
})();
