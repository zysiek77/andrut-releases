// Start of the Fiori Elements V2 app in Andrut (no backend, no Fiori Launchpad):
// 1. MockServer answers the OData V2 requests in the browser (metadata.xml + mockdata/<EntitySet>.json),
// 2. a stub replaces the launchpad's ShellUIService (without it Fiori Elements throws on start),
// 3. the component demo.fe (manifest.json) is created and placed on the page.
// Rows of every entity set are kept between visits (andrut.setData under "fe_<EntitySet>").
sap.ui.define([
  "sap/ui/core/util/MockServer", "sap/ui/core/ComponentContainer",
  "sap/ui/core/service/Service", "sap/ui/core/service/ServiceFactory", "sap/ui/core/service/ServiceFactoryRegistry",
  "sap/ui/core/ElementRegistry"
], function (MockServer, ComponentContainer, Service, ServiceFactory, ServiceFactoryRegistry, ElementRegistry) {
  "use strict";
  // Must be the same as sap.app/dataSources/mainService/uri in manifest.json.
  var SERVICE_URI = "/sap/opu/odata/sap/ZREJESTRACJA_SRV/";
  var hasAndrut = typeof window.andrut !== "undefined";
  var base = sap.ui.require.toUrl("demo/fe/localService");
  // sets: entity set name -> { props: property names, types: property -> Edm type, keys: key names, type: "Namespace.EntityType" }
  var server = null, sets = {};

  var ShellStub = Service.extend("demo.fe.ShellUIServiceStub", {
    setTitle: function (t) { document.title = t; }, getTitle: function () { return document.title; },
    setHierarchy: function () {}, setRelatedApps: function () {}, setBackNavigation: function () {},
    attachEvent: function () {}, detachEvent: function () {}
  });
  ServiceFactoryRegistry.register("sap.ushell.ui5service.ShellUIService", new ServiceFactory(ShellStub));

  // The start is over when the first page is drawn: Andrut's check_world waits for this signal (set in index.html).
  function ready() {
    var t0 = Date.now(), timer = setInterval(function () {
      if (document.querySelector(".sapMListTbl, .sapUxAPObjectPageLayout") || Date.now() - t0 > 15000) { clearInterval(timer); window.andrutLoading = false; }
    }, 200);
  }
  function fail(e) {
    window.andrutLoading = false;
    document.getElementById("loading").textContent = "Fiori Elements failed to start: " + e.message;
    console.error("Fiori Elements: " + (e.stack || e.message));
  }
  function readSets(xml) {
    var doc = new DOMParser().parseFromString(xml, "application/xml"), types = {};
    var ns = doc.getElementsByTagName("Schema")[0].getAttribute("Namespace");
    Array.prototype.forEach.call(doc.getElementsByTagName("EntityType"), function (t) {
      var info = { props: [], types: {}, keys: [], type: ns + "." + t.getAttribute("Name") };
      Array.prototype.forEach.call(t.getElementsByTagName("Property"), function (p) {
        info.props.push(p.getAttribute("Name")); info.types[p.getAttribute("Name")] = p.getAttribute("Type");
      });
      Array.prototype.forEach.call(t.getElementsByTagName("PropertyRef"), function (k) {
        if (k.parentNode.nodeName === "Key") info.keys.push(k.getAttribute("Name"));
      });
      types[t.getAttribute("Name")] = info;
    });
    Array.prototype.forEach.call(doc.getElementsByTagName("EntitySet"), function (s) {
      sets[s.getAttribute("Name")] = types[s.getAttribute("EntityType").split(".").pop()];
    });
  }
  function keyUri(set, row) {
    var info = sets[set];
    var parts = info.keys.map(function (k) {
      var v = info.types[k] === "Edm.String" ? "'" + encodeURIComponent(String(row[k]).replace(/'/g, "''")) + "'" : row[k];
      return info.keys.length > 1 ? k + "=" + v : v;
    });
    return SERVICE_URI + set + "(" + parts.join(",") + ")";
  }
  // MockServer needs complete rows: it answers 404 for a whole table when one row lacks a selected property
  // (a row created in the app has no empty fields), and rows without __metadata (imported ones) are not shown.
  function normalize() {
    Object.keys(sets).forEach(function (set) {
      var rows = server.getEntitySetData(set), changed = false;
      rows.forEach(function (row) {
        sets[set].props.forEach(function (prop) { if (!(prop in row)) { row[prop] = null; changed = true; } });
        if (!row.__metadata) { var uri = keyUri(set, row); row.__metadata = { id: uri, uri: uri, type: sets[set].type }; changed = true; }
      });
      if (changed) server.setEntitySetData(set, rows);
    });
  }
  // TotalCost of every registration order = sum of the Amount of its cost lines (RegCosts).
  // Runs before each save, so it also follows costs added, changed or deleted in the app.
  function recalcTotals() {
    var costs = server.getEntitySetData("RegCosts"), sums = {};
    costs.forEach(function (c) {
      var id = c.RegOrderID; if (!id) return;
      sums[id] = (sums[id] || 0) + Math.round((parseFloat(c.Amount) || 0) * 100);
    });
    var orders = server.getEntitySetData("RegOrders"), changed = false;
    orders.forEach(function (o) {
      var total = ((sums[o.RegOrderID] || 0) / 100).toFixed(2);
      if (o.TotalCost !== total) { o.TotalCost = total; changed = true; }
    });
    if (changed) server.setEntitySetData("RegOrders", orders);
  }
  function saveAll() {
    normalize();
    recalcTotals();
    if (!hasAndrut) return;
    Object.keys(sets).forEach(function (set) {
      try { andrut.setData("fe_" + set, JSON.stringify(server.getEntitySetData(set))); } catch (e) {}
    });
  }

  fetch(base + "/metadata.xml").then(function (r) { return r.text(); }).then(function (xml) {
    readSets(xml);
    server = new MockServer({ rootUri: SERVICE_URI });
    MockServer.config({ autoRespond: true, autoRespondAfter: 150 });
    server.simulate(base + "/metadata.xml", { sMockdataBaseUrl: base + "/mockdata", bGenerateMissingMockData: true });
    server.start();
    Object.keys(sets).forEach(function (set) {
      try { var raw = hasAndrut ? andrut.getData("fe_" + set) : null; if (raw) server.setEntitySetData(set, JSON.parse(raw)); } catch (e) {}
    });
    normalize();
    recalcTotals();
    // Save after any change. No entity set filter: a child row created through a navigation property
    // (Products('1')/to_Orders) is reported under the parent set. setTimeout: the "after" event fires
    // before the mock data is updated.
    ["POST", "PUT", "MERGE", "PATCH", "DELETE"].forEach(function (method) {
      server.attachAfter(method, function () { setTimeout(saveAll, 0); });
    });
    sap.ui.require(["sap/ui/core/Component"], function (Component) {
      Component.create({ name: "demo.fe", manifest: true }).then(function (comp) {
        document.getElementById("loading").remove();
        new ComponentContainer({ component: comp, height: "100%" }).placeAt("content");
        ready();
        console.log("Fiori Elements ready (SAPUI5 " + sap.ui.version + ")");
      }).catch(fail);
    });
  }).catch(fail);

  // Import rows from own code (CSV import, sync…): importRows("Products", [{ProductID: "X-1", Name: "…"}], false).
  // Rows with an existing key replace the old row; replaceAll = true drops all old rows first. Values must have the
  // types of the mock data (Edm.Decimal as string "12.50", Edm.Int32 as number, Edm.DateTime as "/Date(ms)/").
  // Then refresh the open table: this.extensionAPI.refreshTable() in a controller extension, or location.reload().
  window.importRows = function (set, rows, replaceAll) {
    if (!sets[set]) throw new Error("Unknown entity set " + set + ". Known: " + Object.keys(sets).join(", "));
    var keyOf = function (r) { return sets[set].keys.map(function (k) { return String(r[k]); }).join("|"); };
    var byKey = {}, out = [];
    (replaceAll ? [] : server.getEntitySetData(set)).concat(rows).forEach(function (r) {
      var k = keyOf(r), copy = Object.assign({}, r); delete copy.__metadata;
      if (k in byKey) out[byKey[k]] = copy; else { byKey[k] = out.length; out.push(copy); }
    });
    server.setEntitySetData(set, out);
    saveAll();
    return out.length;
  };
  // Property types and keys of an entity set (from metadata.xml), e.g. for converting imported values.
  window.entitySetInfo = function (set) { return sets[set]; };
  // Current rows of an entity set (copy without __metadata) – for checks with run_js.
  window.getRows = function (set) {
    return server.getEntitySetData(set).map(function (r) { var c = Object.assign({}, r); delete c.__metadata; return c; });
  };

  // ---- Helpers for testing with run_js (they work on UI5 controls, so also on buttons hidden in an overflow menu) ----
  function label(c) {
    try { return (c.getText && c.getText()) || (c.getTitle && c.getTitle()) || (c.getTooltip_AsString && c.getTooltip_AsString()) || ""; }
    catch (e) { return ""; } // some controls throw outside their container
  }
  function visible(c) { try { return c.getVisible ? c.getVisible() : true; } catch (e) { return false; } }
  function unique(list) { return list.filter(function (x, i) { return x && list.indexOf(x) === i; }); }
  function controls(test) { var out = []; ElementRegistry.forEach(function (c) { if (test(c)) out.push(c); }); return out; }
  function matches(c, what) { return c.getId().slice(-what.length) === what || label(c) === what; }
  window.ui5Test = {
    // ui5Test.buttons() -> every button: "id suffix | text | visible | on screen"
    buttons: function () {
      return controls(function (c) { return typeof c.firePress === "function" && c.isA("sap.m.Button"); }).map(function (c) {
        return c.getId().split("--").pop() + " | " + label(c) + " | visible=" + c.getVisible() + " | onScreen=" + !!(c.getDomRef() && c.getDomRef().offsetParent);
      });
    },
    // ui5Test.find("Process") -> controls whose id contains the text or whose label equals it
    find: function (what) {
      return controls(function (c) { return c.getId().indexOf(what) >= 0 || label(c) === what; }).map(function (c) {
        return c.getMetadata().getName() + " " + c.getId().split("--").pop() + " | " + label(c) + " | visible=" + visible(c) + " | onScreen=" + !!(c.getDomRef() && c.getDomRef().offsetParent);
      });
    },
    // ui5Test.press("Import CSV") or ui5Test.press("ImportCsvButton") -> presses the button (id suffix or exact text)
    press: function (what) {
      var found = controls(function (c) { return typeof c.firePress === "function" && c.getVisible() && matches(c, what); });
      if (!found.length) {
        return "no visible button \"" + what + "\". Visible buttons: " + unique(controls(function (c) {
          return typeof c.firePress === "function" && c.isA("sap.m.Button") && c.getVisible();
        }).map(label)).slice(0, 40).join(", ");
      }
      found[0].firePress();
      return "pressed " + found[0].getId().split("--").pop() + (found.length > 1 ? " (first of " + found.length + ")" : "");
    },
    // ui5Test.openRow("P-100") -> opens the first table row that contains the text (navigation to its object page)
    openRow: function (text) {
      var rows = controls(function (c) { return c.isA("sap.m.ColumnListItem") && c.getDomRef() && c.getDomRef().innerText.indexOf(text) >= 0; });
      if (!rows.length) return "no table row contains \"" + text + "\"";
      rows[0].getParent().fireItemPress({ listItem: rows[0] });
      return "opened row " + rows[0].getDomRef().innerText.replace(/\s+/g, " ").trim().slice(0, 80);
    },
    // ui5Test.screen() -> route, open dialogs / message toasts, texts of the visible buttons
    screen: function () {
      var texts = function (sel) { return Array.prototype.map.call(document.querySelectorAll(sel), function (e) { return e.innerText.replace(/\s+/g, " ").trim().slice(0, 200); }); };
      return JSON.stringify({ route: location.hash, dialogs: texts(".sapMDialog"), toasts: texts(".sapMMessageToast"),
        buttonsOnScreen: unique(window.ui5Test.buttons().filter(function (b) { return /onScreen=true/.test(b); }).map(function (b) { return b.split(" | ")[1]; })) });
    }
  };

  // Reset to the rows from mockdata/*.json: call from run_js, then reload the world.
  window.resetMockData = function () { Object.keys(sets).forEach(function (set) { if (hasAndrut) andrut.removeData("fe_" + set); }); };
  // State for the AI (check_world / look_at_world read it).
  window.andrutDescribe = function () {
    return "Fiori Elements V2 (SAPUI5 " + sap.ui.version + "), route: " + (location.hash || "list report") + ", rows: " +
      Object.keys(sets).map(function (s) { return s + "=" + (server ? server.getEntitySetData(s).length : "?"); }).join(", ");
  };
});
