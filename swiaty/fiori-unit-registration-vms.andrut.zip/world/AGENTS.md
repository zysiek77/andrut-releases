# Agreements – rejestracja samochodow vms

- Language of UI: Polish. Chat with user: Polish.
- Tech: SAP Fiori Elements (OData V2, MockServer, ui5-fiori-elements skill), data in browser.
- Entities (service ZREJESTRACJA_SRV):
  - RegOrder (Zlecenie, header): RegOrderID, Customer, VehicleType (CAR/MOTO), VIN, Plate, Status, OrderDate, TotalCost (manual), Currency, Note.
  - RegCost (Koszt, child of order): CostID, RegOrderID, CostType, Amount, Currency, Note.
  - RegVisit (Wizyta, child of order): VisitID, RegOrderID, Office, VisitDate, VisitTime, Status, Note.
  - Dictionaries with value help: Customers, VehicleTypes, OrderStatuses, CostTypes (price list with DefaultAmount), Currencies, Offices, VisitStatuses.
- Decisions:
  - Costs are picked from the price list (CostTypes) in the order; amount can be changed.
  - Full CRUD. Sums are typed manually (no business logic).
  - Amounts in PLN. UI in Polish.
  - Visits: child table in the order (done). Separate list of all visits: NOT working yet – a second ListReport root in manifest.json gives an empty screen. Open question for the user.
- Files: index.html (start), fe/start.js (MockServer start), fe/manifest.json (pages), fe/localService/metadata.xml + annotations.xml, fe/localService/mockdata/*.json (one per entity set).
